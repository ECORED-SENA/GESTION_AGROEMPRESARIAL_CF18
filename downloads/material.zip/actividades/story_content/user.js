function ExecuteScript(strId)
{
  switch (strId)
  {
      case "603AKfeN31m":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

